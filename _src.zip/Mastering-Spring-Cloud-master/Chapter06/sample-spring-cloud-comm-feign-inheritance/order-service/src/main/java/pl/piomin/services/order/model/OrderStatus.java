package pl.piomin.services.order.model;

public enum OrderStatus {

	NEW, PROCESSING, ACCEPTED, DONE, REJECTED;
	
}
