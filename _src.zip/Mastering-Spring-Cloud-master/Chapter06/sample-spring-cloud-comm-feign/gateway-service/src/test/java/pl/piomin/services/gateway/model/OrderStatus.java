package pl.piomin.services.gateway.model;

public enum OrderStatus {

	NEW, PROCESSING, ACCEPTED, DONE, REJECTED;
	
}
