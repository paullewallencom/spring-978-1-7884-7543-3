package pl.piomin.services.gateway.model;

public enum CustomerType {

	NEW, REGULAR, VIP;
	
}
